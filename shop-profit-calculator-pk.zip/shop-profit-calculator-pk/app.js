const $ = (id) => document.getElementById(id);
const fields = ["productName","buyPrice","sellPrice","quantity","expenses"];
let sales = loadSales();

function loadSales(){ try { return JSON.parse(localStorage.getItem("shopProfitSales") || "[]"); } catch { return []; } }
function persist(){ localStorage.setItem("shopProfitSales", JSON.stringify(sales)); }
function money(value){ return new Intl.NumberFormat("en-PK",{style:"currency",currency:"PKR",maximumFractionDigits:2}).format(Number(value)||0); }
function values(){
  const buy = Math.max(0, Number($("buyPrice").value)||0);
  const sell = Math.max(0, Number($("sellPrice").value)||0);
  const qty = Math.max(1, Math.floor(Number($("quantity").value)||1));
  const expenses = Math.max(0, Number($("expenses").value)||0);
  const totalSales = sell * qty;
  const totalCost = buy * qty + expenses;
  const profit = totalSales - totalCost;
  const margin = totalSales > 0 ? profit / totalSales * 100 : 0;
  return {buy,sell,qty,expenses,totalSales,totalCost,profit,margin};
}
function updatePreview(){
  const v=values();
  $("previewSales").textContent=money(v.totalSales);
  $("previewProfit").textContent=money(v.profit);
  $("previewMargin").textContent=(Number.isFinite(v.margin)?v.margin:0).toFixed(1)+"%";
}
fields.slice(1).forEach(id => $(id).addEventListener("input",updatePreview));

$("saleForm").addEventListener("submit", (event)=>{
  event.preventDefault();
  const name=$("productName").value.trim();
  const v=values();
  if(!name){alert("Please enter a product name.");return;}
  if(v.sell<=0){alert("Selling price must be greater than zero.");return;}
  if(v.buy<0||v.expenses<0||v.qty<1){alert("Please enter valid prices, expenses and quantity.");return;}
  sales.unshift({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),name,...v,date:new Date().toISOString()});
  persist(); render();
  $("saleForm").reset(); $("quantity").value=1; $("expenses").value=0; updatePreview();
  $("productName").focus();
});
$("searchInput").addEventListener("input",render);
$("periodFilter").addEventListener("change",render);

function filteredSales(){
  const query=$("searchInput").value.trim().toLowerCase();
  const period=$("periodFilter").value;
  const now=new Date();
  return sales.filter(s=>{
    if(query&&!s.name.toLowerCase().includes(query))return false;
    const d=new Date(s.date);
    if(period==="today")return d.toDateString()===now.toDateString();
    if(period==="week")return d>=new Date(now.getTime()-7*86400000);
    if(period==="month")return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth();
    return true;
  });
}
function render(){
  const totalSales=sales.reduce((a,s)=>a+s.totalSales,0);
  const totalCost=sales.reduce((a,s)=>a+s.totalCost,0);
  const profit=totalSales-totalCost;
  $("totalSales").textContent=money(totalSales);
  $("totalCost").textContent=money(totalCost);
  $("netProfit").textContent=money(profit);
  const shown=filteredSales();
  $("recordCount").textContent=`${shown.length} record${shown.length===1?"":"s"} shown`;
  const list=$("salesList");
  if(!shown.length){list.innerHTML='<div class="empty-state">No matching sales yet. Add a sale using the form above.</div>';return;}
  list.innerHTML=shown.map(s=>`
    <article class="sale-item">
      <div class="sale-main"><h3>${escapeHtml(s.name)}</h3>
        <div class="sale-meta">${new Date(s.date).toLocaleString()}<br>
        ${s.qty} × ${money(s.sell)} selling · Cost ${money(s.buy*s.qty)} · Expenses ${money(s.expenses)}</div>
      </div>
      <div class="sale-numbers"><strong>${money(s.profit)}</strong><span>Net profit</span>
        <div class="sale-actions"><button class="delete-btn" data-delete="${s.id}" type="button">Delete</button></div>
      </div>
    </article>`).join("");
  list.querySelectorAll("[data-delete]").forEach(btn=>btn.addEventListener("click",()=>{
    const item=sales.find(s=>s.id===btn.dataset.delete);
    if(item&&confirm(`Delete sale "${item.name}"?`)){sales=sales.filter(s=>s.id!==item.id);persist();render();}
  }));
}
function escapeHtml(str){return String(str).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("exportBtn").addEventListener("click",()=>{
  if(!sales.length){alert("There are no sales to export yet.");return;}
  const headers=["Date","Product","Buying Price","Selling Price","Quantity","Expenses","Total Sales","Total Cost","Net Profit","Profit Margin %"];
  const rows=sales.map(s=>[new Date(s.date).toLocaleString(),s.name,s.buy,s.sell,s.qty,s.expenses,s.totalSales,s.totalCost,s.profit,s.margin.toFixed(2)]);
  const csv=[headers,...rows].map(row=>row.map(value=>`"${String(value).replace(/"/g,'""')}"`).join(",")).join("\r\n");
  const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8;"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="shop-sales.csv";a.click();URL.revokeObjectURL(url);
});
updatePreview();render();
